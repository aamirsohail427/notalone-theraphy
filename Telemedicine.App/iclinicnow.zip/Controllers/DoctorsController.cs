﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Telemedicine.Models.Dtos;
using Telemedicine.Models.Dtos.RequestDto;
using Telemedicine.Services.Interfaces;
using Telemedicine.Utilities;

namespace Telemedicine.App.Controllers
{
    [Authorize(Roles = RoleStrings.ClientOnly)]
    public class DoctorsController : Controller
    {
        private readonly IDoctorProfileService _doctorProfileService;
        private readonly ISessionManager _sessionManager;

        public DoctorsController(IDoctorProfileService doctorProfileService, ISessionManager sessionManager)
        {
            _doctorProfileService = doctorProfileService;
            _sessionManager = sessionManager;
        }
        
        [HttpGet]
        public IActionResult Index()
        {
            string message = "";
            string doctorId = "";
            
            if (!(TempData["PaymentStatus"] is null))
                message = Convert.ToString(TempData["PaymentStatus"]);

            if(!(TempData["PaymentStatus"] is null))
                doctorId = Convert.ToString(TempData["DoctorId"]);
            
            ViewBag.Message = message;
            ViewBag.DoctorId = doctorId;
            
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> Profile(int id)
        {
            //var result = await _doctorProfileService.GetDoctorProfileDetailByUserAsync(new RequestDto<long>() { Key = id });
            var result = await _doctorProfileService.GetDoctorDetailAsync(new RequestDto<long>() { Key = id });
            return View(result.Data);
        }

        [HttpPost]
        public async Task<IActionResult> GetDoctors(GetDoctorsByFiltersRequestDto getDoctorsByFiltersRequestDto)
        {
            //var data = await _doctorProfileService.GetDoctorsByFiltersAsync(getDoctorsByFiltersRequestDto);
            var data = await _doctorProfileService.GetDoctorsByDoctorNameAndStateAsync(getDoctorsByFiltersRequestDto);
            return PartialView("~/Views/Doctors/PartialViews/_DoctorsDetail.cshtml", data.Data);
        }

        [HttpPost]
        public IActionResult GetAppointmentReasonForm()
        {
            return PartialView("~/Views/Doctors/PartialViews/_Q2AppointmentFlow.cshtml");
        }

        [HttpPost]
        public IActionResult GetLocationForm()
        {
            return PartialView("~/Views/Doctors/PartialViews/_Q3AppointmentFlow.cshtml");
        }

        [HttpPost]
        public IActionResult GetConcernForm()
        {
            return PartialView("~/Views/Doctors/PartialViews/_Q4AppointmentFlow.cshtml");
        }

        [HttpPost]
        public IActionResult GetDoctorsDetail()
        {
            return PartialView("~/Views/Doctors/PartialViews/_DoctorsDetail.cshtml");
        }
    }
}